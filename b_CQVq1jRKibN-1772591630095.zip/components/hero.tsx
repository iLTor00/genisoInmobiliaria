"use client"

import Image from "next/image"
import { ArrowDown } from "lucide-react"
import { useScrollReveal } from "@/hooks/use-scroll-reveal"

const WHATSAPP_URL =
  "https://wa.me/541155812392?text=Hola%2C%20me%20contacto%20desde%20la%20web"

export function Hero() {
  const { ref, isVisible } = useScrollReveal(0.1)

  return (
    <section
      ref={ref}
      className="relative flex min-h-screen items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <Image
        src="/images/hero-bg.jpg"
        alt="Barrio residencial en Buenos Aires"
        fill
        className="object-cover"
        priority
      />

      {/* Multi-layer overlay for depth */}
      <div className="absolute inset-0 bg-gradient-to-b from-foreground/70 via-foreground/50 to-foreground/80" />
      <div className="absolute inset-0 bg-gradient-to-r from-primary/15 via-transparent to-transparent" />

      {/* Content */}
      <div
        className={`relative z-10 mx-auto max-w-3xl px-5 py-32 text-center transition-all duration-1000 ease-out lg:px-8 ${
          isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
        }`}
      >
        {/* Location badge */}
        <div className="mb-8 inline-flex items-center gap-2.5 rounded-full border border-background/15 bg-background/8 px-5 py-2 backdrop-blur-md">
          <span className="h-1.5 w-1.5 rounded-full bg-accent" />
          <span className="text-xs font-medium uppercase tracking-[0.18em] text-background/85">
            Ramos Mejia, Buenos Aires
          </span>
        </div>

        <h1 className="font-heading text-balance text-4xl font-bold leading-[1.1] tracking-tight text-background sm:text-5xl md:text-6xl lg:text-7xl">
          Inmobiliaria Geniso
        </h1>

        <p className="mx-auto mt-5 max-w-md text-lg leading-relaxed text-background/70 sm:text-xl md:mt-6">
          Desde 1987 en Ramos Mejia
        </p>

        {/* CTAs */}
        <div className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row md:mt-12">
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 rounded-lg bg-whatsapp px-7 py-3.5 text-sm font-semibold text-background shadow-lg shadow-whatsapp/25 transition-all hover:shadow-xl hover:shadow-whatsapp/30 hover:brightness-110"
          >
            <svg viewBox="0 0 24 24" className="h-[18px] w-[18px] fill-current" aria-hidden="true">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            Escribinos por WhatsApp
          </a>
          <a
            href="#propiedades"
            className="inline-flex items-center gap-2 rounded-lg border border-background/25 bg-background/10 px-7 py-3.5 text-sm font-semibold text-background backdrop-blur-sm transition-all hover:bg-background/20"
          >
            Ver propiedades
          </a>
        </div>
      </div>

      {/* Scroll hint */}
      <div className="absolute bottom-8 left-1/2 z-10 -translate-x-1/2 animate-bounce">
        <ArrowDown className="h-5 w-5 text-background/40" />
      </div>
    </section>
  )
}
